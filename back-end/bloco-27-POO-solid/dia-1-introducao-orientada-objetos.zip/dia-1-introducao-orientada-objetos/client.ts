class Client {
  public name: string;
  
  constructor(name: string) {
    this.name = name;
  }
}

export default Client;